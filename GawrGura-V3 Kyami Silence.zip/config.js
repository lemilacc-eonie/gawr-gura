global.owner = ['6285696558295']  
global.mods = ['6285696558295'] 
global.prems = ['6285696558295']
global.nameowner = 'Çheriellen'
global.namecreator = 'Çheriellen'
global.namebot = 'GawrGura V3'
global.numberowner = '6285696558295' 
global.mail = '@lemilacc@gmail.com' 
global.gc = 'https://chat.whatsapp.com/CVmJg94MmfE0VwOUtcRjeV?mode=ac_t'
global.instagram = 'https://instagram.com/lemilacc'
global.wm = '© Çheriellen'
global.wait = '_*Tunggu sedang di proses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With Cherry'
global.author = 'Cherry'
global.autobio = true // Set true untuk mengaktifkan autobio
global.maxwarn = '3' // Peringatan maksimum
global.antiporn = true // Auto delete pesan porno (bot harus admin)

global.my = {
	yt: '-',
	gh: 'Chartëris',
	gc: 'https://chat.whatsapp.com/CVmJg94MmfE0VwOUtcRjeV?mode=ac_t',
	ch: '-,
}
//INI WAJIB DI ISI!//
global.btc = 'gtkCkMVp' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = 'apikey'
//Daftar https://api.betabotz.eu.org 

//jangan diganti!
global.APIs = {   
  btc: 'https://api.botcahx.eu.org'
}

//ini tidak di isi juga tidak apa-apa
global.APIKeys = { 
  'https://api.botcahx.eu.org': 'tnUW4mZs' 
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
